public class Ortalama {
    public double ortalamaHesaplama(int vize, int Final){
        if(vize < 0 || vize > 100 || Final < 0 || Final > 100)
            return -1;
        else
            return vize*0.4 + Final*0.6;
    }
}
