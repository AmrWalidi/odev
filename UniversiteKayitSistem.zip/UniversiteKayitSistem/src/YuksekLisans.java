public class YuksekLisans extends Ogrenci{
    private String program;
    private int mezunyetYili;
    private Ortalama ort = new Ortalama();

    public YuksekLisans() {
    }

    public YuksekLisans(String ad, String soyad, String kimlikTC, String ID, String mail,int ogrenmeSuresi, String program, int mezunyetYili,int vizeNotu, int finalNotu, double GNO) {
        super(ad, soyad, ID,mail, kimlikTC,ogrenmeSuresi,vizeNotu, finalNotu, GNO);
        this.program = program;
        if(mezunyetYili > 2022)
            mezunyetYili = -1;
        this.mezunyetYili = mezunyetYili;
    }

    @Override
    public int getVizeNotu() {
        if(vizeNotu < 0 || vizeNotu > 100)
            return -1;
        return vizeNotu;
    }
    @Override
    public int getFinalNotu() {
        if(finalNotu < 0 || finalNotu > 100)
            return -1;
        return finalNotu;
    }

    @Override
    public double getGNO() {
        if(GNO < 0 || GNO > 4)
            return -1;
        return GNO;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getMezunyetYili() {
        if(mezunyetYili > 2022)
            return -1;
        return mezunyetYili;
    }

    public void setMezunyetYili(int mezunyetYili) {
        this.mezunyetYili = mezunyetYili;
    }

    @Override
    void ortalamaHesaplama(int vize, int Final) {
        System.out.println(ort.ortalamaHesaplama(vize,Final));
    }

    @Override
    protected double ortalamaHesaplama() {
        return ort.ortalamaHesaplama(vizeNotu,finalNotu);
    }

    @Override
    public String toString() {
        return "\n\n"+"Yüksek Lisans Öğrenci: "+ '\n' +
                info +
                "Vize Notu : " + vizeNotu + '\n' +
                "Final Notu : " + finalNotu + '\n' +
                "GNO : " + GNO + '\n' +
                "Ogrenme Suresi : " + ogrenmeSuresi + '\n' +
                "Ortalama : " + ortalamaHesaplama() + '\n' +
                "Program : " + program + '\n' +
                "Mezuniyet Yılı : " + mezunyetYili;
    }

}
