import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class BasarliKayit extends UniversiteKayitEkrani {
    JPanel basar;
    JLabel basari;
    JButton yazdir;
    JButton yeniKayit;
    BasarliKayit(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        basar = new JPanel();
        basari = new JLabel("Başarlı Kayıt");
        yazdir = new JButton("Tüm Kullanıcıların Bilgileri Yazdır");
        yeniKayit = new JButton("Yeni Kullanıcı Kaydet");
        basari.setFont(new Font("Arial",Font.BOLD,35));
        basari.setForeground(new Color(255,255,255));
        basari.setBounds(90,100,300,40);
        yazdir.setFont(new Font("Arial",Font.PLAIN,15));
        yazdir.setBounds(60,240,260,30);
        yazdir.setFocusPainted(false);
        yazdir.addActionListener(this);
        yeniKayit.setFont(new Font("Arial",Font.PLAIN,15));
        yeniKayit.setBounds(100,200,190,30);
        yeniKayit.addActionListener(this);
        yeniKayit.setFocusPainted(false);
        setSize(400,330);
        setContentPane(basar);
        basar.setSize(400,300);
        basar.setVisible(true);
        basar.setLayout(null);
        basar.add(background);
        background.add(basari);
        background.add(yazdir);
        background.add(yeniKayit);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == yeniKayit){
            new UniversiteKayitEkrani();
            dispose();
        }
        if(e.getSource() == yazdir){
            Universite uni = new Universite(kullaniciler);
            FileHandling f = new FileHandling();
            f.Write(uni);
            new bilgiler();
            dispose();
        }
    }
}
