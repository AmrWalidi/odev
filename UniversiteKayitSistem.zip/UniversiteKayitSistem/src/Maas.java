public class Maas {
    public int akademikMaas(int gunler){
        return gunler*1000;
    }

    public int idariMaas(int gunler){
        return gunler*800;
    }
}
