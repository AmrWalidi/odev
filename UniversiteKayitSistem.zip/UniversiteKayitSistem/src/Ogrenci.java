abstract public class Ogrenci implements kullaniciler {
    int vizeNotu;
    int finalNotu;
    double GNO;
    int ogrenmeSuresi;
    PersonalInfo info;

    public Ogrenci(){};
    public Ogrenci(String ad, String soyad, String ID,String mail, String kimlikTC,int ogrenmeSuresi,int vizeNotu, int finalNotu, double GNO) {
        if(vizeNotu < 0 || vizeNotu > 100)
            this.vizeNotu = -1;
        else
            this.vizeNotu = vizeNotu;

        if(finalNotu < 0 || finalNotu > 100)
            this.finalNotu = -1;
        else
            this.finalNotu = finalNotu;

        if(GNO < 0 || GNO > 4)
            this.GNO = -1;
        else
            this.GNO =GNO;

        this.info = new PersonalInfo(ad,soyad,ID,mail,kimlikTC);
        this.ogrenmeSuresi = ogrenmeSuresi;
    }
    abstract void ortalamaHesaplama(int vize, int Final);

    abstract double ortalamaHesaplama();

    public int getVizeNotu() {
        return vizeNotu;
    }

    public void setVizeNotu(byte vizeNotu) {
        this.vizeNotu=vizeNotu;
    }

    public int getFinalNotu() {
        return finalNotu;
    }

    public void setFinalNotu(byte finalNotu) {
        this.finalNotu=finalNotu;
    }

    public double getGNO() {
        return GNO;
    }

    public void setGNO(double GNO) {
        this.GNO=GNO;
    }

    public int getOgrenmeSuresi() {
        return ogrenmeSuresi;
    }

    public void setOgrenmeSuresi(int ogrenmeSuresi) {
        this.ogrenmeSuresi=ogrenmeSuresi;
    }

}
