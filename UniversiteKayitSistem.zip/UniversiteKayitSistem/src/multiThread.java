public class multiThread extends LoadingEkrani {
    private boolean shutdown = true;
    class Loading extends Thread {
        @Override
        public void run() {
            while (shutdown){
                loading.setText("Kaydediliyor .");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                loading.setText("Kaydediliyor ..");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                loading.setText("Kaydediliyor ...");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    class LoadingBar extends Thread{
        @Override
        public void run() {
            for (int i = 0; i <= 100; i++) {
                loadBar.setValue(i);
                try {
                    Thread.sleep(65);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    class LoadingPercent extends Thread{
        @Override
        public void run() {
            for (int i = 0; i <= 100; i++) {
                loadPercent.setText(i+"%");
                try {
                    Thread.sleep(70);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            shutdown = false;
            new BasarliKayit();
            dispose();
        }
    }
}
