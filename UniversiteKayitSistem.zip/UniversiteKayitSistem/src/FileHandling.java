import java.io.*;

public class FileHandling {
    BufferedReader fr;
    BufferedWriter fw;
    java.io.File file;
    String line;
    String metin="";
    public void Write(Universite uni){
        try {
            file = new java.io.File("Kayıtlar.txt");
            fw = new BufferedWriter(new FileWriter(file,true));
            if (file.length() == 0){
                fw.write(uni.toString());
            }
            else{
                fw.write(uni.bilgiler());
            }
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String Read() {
        try {
            fr = new BufferedReader(new FileReader("Kayıtlar.txt"));
            line = fr.readLine();
            while (line != null) {
                metin += (line + "\n");
                line = fr.readLine();
            }
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return metin;
    }
}
