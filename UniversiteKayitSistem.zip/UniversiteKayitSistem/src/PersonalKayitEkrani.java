import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class PersonalKayitEkrani extends UniversiteKayitEkrani{

    JPanel panel3;
    JPanel pIdari;
    JPanel pAkadimi;
    JLabel LcalismaGunler;
    JLabel LcalismaBaslamisYili;
    JLabel LverilenDers;
    JLabel Lgorev;
    JLabel LarastirmaAlani;
    JTextField TcalismaGunler;
    JTextField TcalismaBaslamisYili;
    JTextField TverilenDers;
    JTextField Tgorev;
    JTextField TarastirmaAlani;

    JButton Bback;
    JButton Bakadimik;
    JButton Bidari;
    JButton Bkaydet;

    static int calismaBaslamisYili;
    static int calismaGun;
    static String gorev;
    static String verilenDers;
    static String arastirmaAlani;


    PersonalKayitEkrani(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        panel3 =new JPanel();
        pIdari =new JPanel();
        pAkadimi=new JPanel();
        LcalismaGunler=new JLabel();
        LcalismaBaslamisYili=new JLabel();
        Lgorev=new JLabel();
        LverilenDers=new JLabel();
        LarastirmaAlani=new JLabel();
        TcalismaGunler=new JTextField();
        TarastirmaAlani=new JTextField();
        TcalismaBaslamisYili=new JTextField();
        Tgorev=new JTextField();
        TverilenDers=new JTextField();
        Bback=new JButton();
        Bakadimik=new JButton();
        Bidari=new JButton();
        Bkaydet=new JButton();
        Bback.addActionListener(this);
        Bback.setFocusPainted(false);
        Bback.setText("Back");
        Bback.setBounds(10,10,70,20);
        Bakadimik.addActionListener(this);
        Bakadimik.setFocusPainted(false);
        Bakadimik.setText("Akadimik");
        Bakadimik.setBounds(100,160,100,30);
        Bidari.addActionListener(this);
        Bidari.setFocusPainted(false);
        Bidari.setText("Idari");
        Bidari.setBounds(220,160,100,30);
        Bkaydet.addActionListener(this);
        Bkaydet.setText("Kaydet");
        Bkaydet.setFocusPainted(false);
        Bkaydet.setBounds(160,300,80,30);
        LcalismaGunler.setText("Calışma Günleri");
        LcalismaGunler.setFont(new Font("Arial",Font.BOLD,15));
        LcalismaGunler.setBounds(10,100,120,25);
        LcalismaGunler.setForeground(new Color(255,255,255));
        TcalismaGunler.setBounds(135,100,100,20);
        LcalismaBaslamisYili.setText("Çalışma Başlamış Yılı");
        LcalismaBaslamisYili.setFont(new Font("Arial",Font.BOLD,15));
        LcalismaBaslamisYili.setForeground(new Color(255,255,255));
        LcalismaBaslamisYili.setBounds(10,70,165,20);
        TcalismaBaslamisYili.setBounds(170,70,100,20);
        LverilenDers.setText("Verilen Ders");
        LverilenDers.setFont(new Font("Arial",Font.BOLD,15));
        LverilenDers.setForeground(new Color(255,255,255));
        LverilenDers.setBounds(10,260,130,20);
        TverilenDers.setBounds(130,260,100,20);
        TverilenDers.setVisible(false);
        LverilenDers.setVisible(false);
        LarastirmaAlani.setText("Araştırma Alanı");
        LarastirmaAlani.setFont(new Font("Arial",Font.BOLD,15));
        LarastirmaAlani.setForeground(new Color(255,255,255));
        LarastirmaAlani.setBounds(10,230,130,20);
        TarastirmaAlani.setBounds(130,230,100,20);
        TarastirmaAlani.setVisible(false);
        LarastirmaAlani.setVisible(false);
        Lgorev.setText("Görev");
        Lgorev.setFont(new Font("Arial",Font.BOLD,15));
        Lgorev.setForeground(new Color(255,255,255));
        Lgorev.setBounds(10,230,130,20);
        Tgorev.setBounds(130,230,100,20);
        Tgorev.setVisible(false);
        Lgorev.setVisible(false);
        setSize(400,400);
        setContentPane(panel3);
        panel3.add(background);
        background.add(LcalismaBaslamisYili);
        background.add(TcalismaBaslamisYili);
        background.add(LcalismaGunler);
        background.add(TcalismaGunler);
        background.add(LverilenDers);
        background.add(TverilenDers);
        background.add(Lgorev);
        background.add(Tgorev);
        background.add(Bidari);
        background.add(Bkaydet);
        background.add(Bback);
        background.add(Bakadimik);
        background.add(TarastirmaAlani);
        background.add(LarastirmaAlani);
        panel3.setVisible(true);
        panel3.setLayout(null);
        panel3.setSize(400,400);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Bback){
            new UniversiteKayitEkrani();
            dispose();
        }
        if(e.getSource()==Bakadimik){
            LverilenDers.setVisible(true);
            TverilenDers.setVisible(true);
            LarastirmaAlani.setVisible(true);
            TarastirmaAlani.setVisible(true);
            Lgorev.setVisible(false);
            Tgorev.setVisible(false);


        }
        if(e.getSource()==Bidari){
            Lgorev.setVisible(true);
            Tgorev.setVisible(true);
            LverilenDers.setVisible(false);
            TverilenDers.setVisible(false);
            LarastirmaAlani.setVisible(false);
            TarastirmaAlani.setVisible(false);
        }

        if(e.getSource() == Bkaydet){
            calismaGun = Integer.parseInt(TcalismaGunler.getText());
            calismaBaslamisYili=Integer.parseInt(TcalismaBaslamisYili.getText());
            if(LverilenDers.isVisible()){
                arastirmaAlani=TarastirmaAlani.getText();
                verilenDers = TverilenDers.getText();
                Personel Ak = new Akademik(fName,lName,No,id,email,arastirmaAlani,calismaBaslamisYili,verilenDers,calismaGun);
                kullaniciler.add(Ak);

            }
            if(Lgorev.isVisible()){
                gorev = Tgorev.getText();
                Personel Id = new Idari(fName,lName,No,id,email,calismaBaslamisYili,gorev,calismaGun);
                kullaniciler.add(Id);
            }
            multiThread multi = new multiThread();
            multiThread.LoadingPercent t1 = multi.new LoadingPercent();
            multiThread.LoadingBar t2 = multi.new LoadingBar();
            multiThread.Loading t3 = multi.new Loading();
            t1.start();
            t2.start();
            t3.start();
            dispose();
        }

    }
}
