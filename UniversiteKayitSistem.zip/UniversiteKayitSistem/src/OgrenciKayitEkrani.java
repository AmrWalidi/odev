import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class OgrenciKayitEkrani extends UniversiteKayitEkrani{
    JPanel panel2;
    JLabel vizeNotu;
    JLabel finalNotu;
    JLabel GNO;
    JLabel ogrenmeSuresi;
    JLabel dersSayisi;
    JLabel program;
    JLabel mezuniyet;
    JTextField programIsmi;
    JTextField mezuniyrtYili;
    JTextField ders;
    JTextField mid;
    JTextField Final;
    JTextField genelNot;
    JTextField period;
    JButton back;
    JButton lisans;
    JButton yukLisans;
    JButton kaydet;
    static int vize;
    static int FinalNot;
    static int ogrenmeSure;
    static double genelOrt;
    static int lesson;
    static int year;
    static String pgrm;
    OgrenciKayitEkrani(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        panel2 = new JPanel();
        vizeNotu = new JLabel();
        finalNotu = new JLabel();
        GNO = new JLabel();
        ogrenmeSuresi = new JLabel();
        dersSayisi = new JLabel();
        program = new JLabel();
        mezuniyet = new JLabel();
        programIsmi = new JTextField();
        mezuniyrtYili = new JTextField();
        ders = new JTextField();
        mid = new JTextField();
        Final = new JTextField();
        genelNot = new JTextField();
        period = new JTextField();
        back = new JButton();
        lisans = new JButton();
        yukLisans = new JButton();
        kaydet = new JButton();
        back.addActionListener(this);
        back.setFocusPainted(false);
        back.setText("Back");
        back.setBounds(10,10,70,20);
        lisans.addActionListener(this);
        lisans.setFocusPainted(false);
        lisans.setText("Lisans");
        lisans.setBounds(100,200,100,30);
        yukLisans.addActionListener(this);
        yukLisans.setFocusPainted(false);
        yukLisans.setText("Yüksek Lisans");
        yukLisans.setBounds(220,200,130,30);
        kaydet.addActionListener(this);
        kaydet.setText("Kaydet");
        kaydet.setFocusPainted(false);
        kaydet.setBounds(160,350,80,30);
        vizeNotu.setText("Vize Notu");
        vizeNotu.setFont(new Font("Arial",Font.BOLD,15));
        vizeNotu.setBounds(10,100,100,25);
        vizeNotu.setForeground(new Color(255,255,255));
        mid.setBounds(120,100,100,20);
        finalNotu.setText("Final Notu");
        finalNotu.setFont(new Font("Arial",Font.BOLD,15));
        finalNotu.setBounds(10,130,100,20);
        finalNotu.setForeground(new Color(255,255,255));
        Final.setBounds(120,130,100,20);
        GNO.setText("Genel Not Ortalama");
        GNO.setFont(new Font("Arial",Font.BOLD,15));
        GNO.setBounds(10,160,160,25);
        GNO.setForeground(new Color(255,255,255));
        genelNot.setBounds(160,160,100,20);
        ogrenmeSuresi.setText("Öğrenme Süresi");
        ogrenmeSuresi.setFont(new Font("Arial",Font.BOLD,15));
        ogrenmeSuresi.setBounds(10,70,130,20);
        ogrenmeSuresi.setForeground(new Color(255,255,255));
        period.setBounds(140,70,100,20);
        dersSayisi.setText("Dersler Sayısı");
        dersSayisi.setFont(new Font("Arial",Font.BOLD,15));
        dersSayisi.setBounds(10,280,130,20);
        dersSayisi.setForeground(new Color(255,255,255));
        ders.setBounds(130,280,100,20);
        ders.setVisible(false);
        dersSayisi.setVisible(false);
        program.setText("Program");
        program.setFont(new Font("Arial",Font.BOLD,15));
        program.setBounds(10,290,70,20);
        program.setForeground(new Color(255,255,255));
        programIsmi.setBounds(80,290,100,20);
        mezuniyet.setText("Mezuniyet Yılı");
        mezuniyet.setFont(new Font("Arial",Font.BOLD,15));
        mezuniyet.setBounds(10,260,120,20);
        mezuniyet.setForeground(new Color(255,255,255));
        mezuniyrtYili.setBounds(120,260,100,20);
        program.setVisible(false);
        programIsmi.setVisible(false);
        mezuniyet.setVisible(false);
        mezuniyrtYili.setVisible(false);
        setVisible(true);
        setSize(400,430);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setContentPane(panel2);
        panel2.add(background);
        background.add(back);
        background.add(vizeNotu);
        background.add(mid);
        background.add(finalNotu);
        background.add(Final);
        background.add(GNO);
        background.add(genelNot);
        background.add(ogrenmeSuresi);
        background.add(period);
        background.add(lisans);
        background.add(yukLisans);
        background.add(dersSayisi);
        background.add(ders);
        background.add(mezuniyet);
        background.add(mezuniyrtYili);
        background.add(programIsmi);
        background.add(program);
        panel2.setVisible(true);
        panel2.setLayout(null);
        panel2.setSize(400,450);
        background.add(kaydet);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==back){
            new UniversiteKayitEkrani();
            dispose();
        }
        if(e.getSource()==lisans){
            ders.setVisible(true);
            dersSayisi.setVisible(true);
            program.setVisible(false);
            programIsmi.setVisible(false);
            mezuniyet.setVisible(false);
            mezuniyrtYili.setVisible(false);
        }
        if(e.getSource()==yukLisans){
            ders.setVisible(false);
            dersSayisi.setVisible(false);
            program.setVisible(true);
            programIsmi.setVisible(true);
            mezuniyet.setVisible(true);
            mezuniyrtYili.setVisible(true);
        }
        if(e.getSource() == kaydet){
            vize = Integer.parseInt(mid.getText());
            FinalNot = Integer.parseInt(Final.getText());
            genelOrt = Double.parseDouble(genelNot.getText());
            ogrenmeSure = Integer.parseInt(period.getText());
            if(ders.isVisible()){
                lesson = Integer.parseInt(ders.getText());
                Ogrenci l = new Lisans(fName,lName,No,id,email,ogrenmeSure,lesson,vize,FinalNot,genelOrt);
                kullaniciler.add(l);

            }
            if(mezuniyet.isVisible()){
                year = Integer.parseInt(mezuniyrtYili.getText());
                pgrm = programIsmi.getText();
                Ogrenci ykl = new YuksekLisans(fName,lName,No,id,email,ogrenmeSure,pgrm,year,vize,FinalNot,genelOrt);
                kullaniciler.add(ykl);
            }
            multiThread multi = new multiThread();
            multiThread.LoadingPercent t1 = multi.new LoadingPercent();
            multiThread.LoadingBar t2 = multi.new LoadingBar();
            multiThread.Loading t3 = multi.new Loading();
            t1.start();
            t2.start();
            t3.start();
            dispose();
        }
    }
}
