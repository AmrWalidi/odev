public class Akademik implements Personel{
    private int calismaGunler;
    private int BaslamisYili;
    private String verilenDers;
    private String arastirmaAlani;
    private PersonalInfo info;
    private Maas ms = new Maas();

    public Akademik() {
    }

    public Akademik(String ad, String soyad, String kimlikTC, String ID, String mail,String arastirmaAlani,int BaslamisYili, String verilenDers,int calismaGunler) {
        if(calismaGunler < 0 || calismaGunler > 31)
            this.calismaGunler = -1;
        else
            this.calismaGunler = calismaGunler;
        if(BaslamisYili > 2022)
            this.BaslamisYili = -1;
        else
            this.BaslamisYili = BaslamisYili;
        this.info = new PersonalInfo(ad,soyad,ID,mail,kimlikTC);
        this.verilenDers = verilenDers;
        this.arastirmaAlani = arastirmaAlani;
    }

    public int getCalismaGunler() {
        if(calismaGunler < 0 || calismaGunler > 31)
            return  -1;
        else
            return calismaGunler;
    }

    public void setCalismaGunler(int calismaGunler) {
        this.calismaGunler=calismaGunler;
    }

    public int getBaslamisYili() {
        if(BaslamisYili > 2022)
            return  -1;
        else
            return BaslamisYili;
    }

    public void setBaslamisYili(int BaslamisYili) {this.BaslamisYili = BaslamisYili;}

    public String getArastirmaAlani() {
        return arastirmaAlani;
    }

    public void setArastirmaAlani(String arastirmaAlani) {
        this.arastirmaAlani = arastirmaAlani;
    }

    public String getVerilenDers() {
        return verilenDers;
    }

    public void setVerilenDers(String verilenDers) {
        this.verilenDers = verilenDers;
    }

    @Override
    public int maasHesaplama() {
        return ms.akademikMaas(calismaGunler);
    }

    @Override
    public String toString() {
        return "\n\n"+"Akademik Personel: "+'\n'+
                info +
                "Maaş : " + maasHesaplama() +'\n'+
                "Çalışma Günleri : " + calismaGunler +'\n'+
                "Verilen Ders : " + verilenDers;
    }
}
