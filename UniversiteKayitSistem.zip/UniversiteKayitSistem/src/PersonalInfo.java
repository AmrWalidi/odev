public class PersonalInfo {
    private String ad;
    private String soyad;
    private String ID;
    private String mail;
    private String kimlikTC;

    public PersonalInfo(){};

    public PersonalInfo(String ad, String soyad, String ID, String mail, String kimlikTC) {
        this.ad = ad;
        this.soyad = soyad;
        this.ID = ID;
        this.mail = mail;
        this.kimlikTC = kimlikTC;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getYas() {
        return mail;
    }

    public void setYas(byte yas) {
        this.mail = mail;
    }

    public String getKimlikTC() {
        return kimlikTC;
    }

    public void setKimlikTC(String kimlikTC) {
        this.kimlikTC = kimlikTC;
    }

    @Override
    public String toString() {
        return "Ad : " + ad + '\n' +
                "Soyad : " + soyad + '\n' +
                "ID : " + ID + '\n' +
                "E-posta : " + mail + '\n'+
                "T.C. Kimlik No : " + kimlikTC + "\n";
    }
}
