import javax.swing.*;
import java.awt.*;

public class bilgiler extends JFrame {
    JTextArea bilgiler;
    JLabel background;
    JScrollPane scroll;
    ImageIcon img;
    bilgiler(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        setFont(new Font("Arial",Font.PLAIN,17));
        FileHandling f = new FileHandling();
        bilgiler = new JTextArea(20,25);
        bilgiler.setFont(new Font("Arial",Font.PLAIN,17));
        bilgiler.setText(f.Read());
        setVisible(true);
        setSize(370,470);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        background.setLayout(new FlowLayout());
        scroll = new JScrollPane(bilgiler);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(background);
        background.add(scroll);
    }
}
