import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class basarliKayit extends JFrame{
    private JButton listelemeButton;
    private JPanel basarlıPane;
    private JButton ekleButton;

    public basarliKayit() {
        setContentPane(basarlıPane);
        setSize(500,500);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        listelemeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kayitListe kayitListe = new kayitListe();
                dispose();
            }
        });
        ekleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Kayit k = new Kayit();
                dispose();
            }
        });
    }
}
