import javax.swing.*;

public class kayitListe extends JFrame {
    private JTextPane textPane1;
    private JPanel panel1;

    public kayitListe(){
        setContentPane(panel1);
        setSize(500,400);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        fileHandling fprint = new fileHandling();
        textPane1.setText(fprint.Read());
    }
}
