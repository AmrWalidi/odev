import java.io.*;

public class fileHandling {
        BufferedWriter fw;
        BufferedReader fr;
        String line;
        String metin="";
    public void Write(String data){
        try {
            fw = new BufferedWriter(new FileWriter("Kayıt_Öğrenciler.txt",true));
            fw.write(data);
            fw.newLine();
            fw.newLine();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String Read(){
        try {
            fr = new BufferedReader(new FileReader("Kayıt_Öğrenciler.txt"));
            line = fr.readLine();
            while (line!=null){
                metin +=(line+"\n");
                line = fr.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return metin;
    }

}
