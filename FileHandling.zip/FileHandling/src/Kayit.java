import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Kayit extends JFrame {
    private JPanel mainPane;
    private JTextField nameField;
    private JTextField noField;
    private JTextField mailField;
    private JTextField passwordField;
    private JButton kayitButton;

    public Kayit(){
        setContentPane(mainPane);
        setSize(500,400);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        kayitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                basarliKayit bk = new basarliKayit();
                String name = nameField.getText();
                String no = noField.getText();
                String mail = mailField.getText();
                String password = passwordField.getText();
                String info = "\nAd: " + name +"\nÖğrenci No: "+ no +"\nE-posta: "+ mail +"\nŞifre:"+ password ;
                fileHandling file = new fileHandling();
                file.Write(info);
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        Kayit k = new Kayit();
    }
}
